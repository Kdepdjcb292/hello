# ChatAI Android

نسخة Android أولية مبنية من منطق سكربت Python المرفوع.

## GitHub
ارفع الملفات إلى مستودع، ثم ادفع إلى `main` أو شغّل:
Actions → Build Android Universal APK → Run workflow

سيظهر ملف APK في Artifacts.

## Universal APK
ABI splits معطلة، لذلك لا يتم تقسيم الناتج إلى ملفات ABI منفصلة.

## مهم
السكربت الأصلي يستخدم endpoint داخلي:
`https://android.chat.openai.com/backend-api/f/conversation`

هذا ليس API عامًا ثابتًا، وقد يتغير أو يتطلب مصادقة. النسخة الحالية تعكس منطق السكربت المرفوع ولا تضيف استخراج Cookies/Tokens أو تسجيل دخول.
