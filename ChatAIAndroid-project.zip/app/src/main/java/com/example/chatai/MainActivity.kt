package com.example.chatai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import java.io.IOException
import java.util.UUID

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChatApp() }
    }
}

@Composable
fun ChatApp() {
    var input by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("🤖 Chat AI") }) },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        Modifier.weight(1f),
                        placeholder = { Text("اكتب رسالتك...") },
                        enabled = !sending,
                        maxLines = 4
                    )
                    Button(
                        enabled = input.isNotBlank() && !sending,
                        onClick = {
                            val prompt = input.trim()
                            input = ""
                            messages += ChatMessage("user", prompt)
                            messages += ChatMessage("assistant", "...")
                            sending = true
                            scope.launch {
                                val result = ChatApi.sendMessage(prompt) { partial ->
                                    val i = messages.lastIndex
                                    if (i >= 0 && messages[i].role == "assistant")
                                        messages[i] = ChatMessage("assistant", partial)
                                }
                                val i = messages.lastIndex
                                if (i >= 0 && messages[i].role == "assistant")
                                    messages[i] = ChatMessage("assistant", result)
                                sending = false
                            }
                        }
                    ) { Text("إرسال") }
                }
            }
        ) { padding ->
            LazyColumn(
                state = listState,
                Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Surface(
                        tonalElevation = 2.dp,
                        shape = MaterialTheme.shapes.medium,
                        Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (msg.role == "user") "أنت: ${msg.text}" else "🤖: ${msg.text}",
                            Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

object ChatApi {
    private const val BASE_URL =
        "https://android.chat.openai.com/backend-api/f/conversation"

    private val client = OkHttpClient()

    suspend fun sendMessage(prompt: String, onPartial: (String) -> Unit): String =
        withContext(Dispatchers.IO) {
            val json = """
            {
              "action":"next",
              "messages":[{
                "id":"${UUID.randomUUID()}",
                "author":{"role":"user"},
                "content":{
                  "content_type":"text",
                  "parts":[${jsonString(prompt)}]
                }
              }],
              "model":"gpt-5.6-Luna",
              "parent_message_id":"${UUID.randomUUID()}",
              "stream":true
            }
            """.trimIndent()

            val request = Request.Builder()
                .url(BASE_URL)
                .addHeader("Accept", "text/event-stream")
                .addHeader("Content-Type", "application/json")
                .addHeader("oai-client-type", "android")
                .addHeader("oai-device-id", UUID.randomUUID().toString())
                .post(json.toRequestBody("application/json".toMediaType()))
                .build()

            val result = StringBuilder()
            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful)
                        return@withContext "❌ HTTP ${response.code}: الخدمة غير متاحة"

                    val source = response.body?.source()
                        ?: return@withContext "⚠️ لا يوجد رد"

                    while (!source.exhausted()) {
                        val line = source.readUtf8Line() ?: continue
                        if (!line.startsWith("data: ")) continue
                        val data = line.removePrefix("data: ").trim()
                        if (data == "[DONE]") break

                        val text = extractAssistantText(data)
                        if (text != null && text.length >= result.length) {
                            result.clear()
                            result.append(text)
                            withContext(Dispatchers.Main) {
                                onPartial(result.toString())
                            }
                        }
                    }
                }
            } catch (e: IOException) {
                return@withContext "🔌 خطأ في الاتصال: ${e.message ?: "غير معروف"}"
            } catch (e: Exception) {
                return@withContext "❌ خطأ: ${e.message ?: "غير معروف"}"
            }
            result.toString().ifBlank { "⚠️ لم يتم الحصول على رد" }
        }

    private fun jsonString(value: String): String =
        "\"" + value.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r") + "\""

    // The source script uses the same endpoint and SSE stream.
    // This parser intentionally targets only the expected assistant text shape.
    private fun extractAssistantText(data: String): String? {
        val p = data.indexOf("\"parts\"")
        if (p < 0) return null
        val start = data.indexOf("[\"", p)
        if (start < 0) return null
        val end = data.indexOf("\"]", start + 2)
        if (end < 0) return null
        return data.substring(start + 2, end)
            .replace("\\\"", "\"")
            .replace("\\n", "\n")
            .replace("\\\\", "\\")
    }
}
